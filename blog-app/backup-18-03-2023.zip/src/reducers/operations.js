export const Fetch_Blogs = 'Fetch_Blogs';
export const New_Blog = 'New_Blog';
export const Update_Blog = 'Update_Blog';
export const Delete_Blog = 'Delete_blog';
